<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(asset('app-assets/js/vendors.min.js')); ?>"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="<?php echo e(asset('app-assets/vendors/chartjs/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/chartist-js/chartist.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/chartist-js/chartist-plugin-tooltip.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/chartist-js/chartist-plugin-fill-donut.min.js')); ?>"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN THEME  JS-->
<script src="<?php echo e(asset('app-assets/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/search.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/custom/custom-script.js')); ?>"></script>
<!-- END THEME  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="<?php echo e(asset('app-assets/js/scripts/dashboard-modern.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/intro.js')); ?>"></script>
<!-- END PAGE LEVEL JS-->

<?php echo $__env->yieldContent('content-js'); ?>
<?php /**PATH C:\xampp\htdocs\file\irham\laravel\resources\views/Layout/Partial/_js.blade.php ENDPATH**/ ?>