<?php $__env->startSection('content-title'); ?>
CRUD
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-main'); ?>
<h4 class="card-title">Data User</h4>
<button class="btn mb-2" id="add">Tambah Data</button>
<table id="dtable" class="display">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Dibuat</th>
            <th>Terakhir Diupdate</th>
            <th>Action</th>
        </tr>
    </thead>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-modal'); ?>
<?php echo $__env->make('Users.Action._add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Users.Action._edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Users.Action._delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Users.Action._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-js'); ?>
<script>
    var dtable = $('#dtable').DataTable({
        language : {
            searchPlaceholder: "Ketik disini ..."
        },
        serverSide : true,
        ajax : "/users",
        columns : [
            { data: 'name' },
            { data: 'email' },
            { data: 'created_at' },
            { data: 'updated_at', format: 'M/D/YYYY' },
            { data: 'action' },
        ],
        stateSave : true,
        deferRender : true,
        pageLength : 5,
        aLengthMenu : [[5,10,25,50,100], [5,10,25,50,100]],
        aoColumnDefs: [
            { "bSortable": false, "aTargets": [4] },
            { "bSearchable": false, "aTargets": [4] }
        ],
        scrollY : "50vh",
    });

    setInterval(function(){
        dtableReload();
    }, 60000);

    function dtableReload(){
        dtable.ajax.reload(function(){
            console.log("Refresh Automatic")
        }, false);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file\irham\resources\views/Users/index.blade.php ENDPATH**/ ?>